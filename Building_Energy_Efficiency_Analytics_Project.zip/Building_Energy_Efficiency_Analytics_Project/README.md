# Building Energy Efficiency Analytics

A browser-based DBMS capstone demonstration website. It includes a dashboard, building records explorer, 10 SQL report examples, 10 visualizations, CSV import/export, database design information and project/team details.

## Open the website
1. Extract the ZIP folder.
2. Open the `Building_Energy_Efficiency_Analytics_Project` folder.
3. Double-click `index.html` (or right-click it and choose Chrome).
4. The project runs locally in Chrome. No installation, server, login or internet connection is required.

## Project structure
- `index.html` – main website page.
- `css/styles.css` – all page styling and responsive layout.
- `js/app.js` – navigation, sample records, calculations, SQL report display, charts and CSV operations.
- `data/sample_building_energy.csv` – 10 sample building records for import/testing.
- `sql/10_analytics_queries.sql` – the 10 SQL queries displayed in the website.
- `sql/database_schema.sql` – SQL table definition.
- `assets/project-flow.svg` – project workflow diagram.

## Main features
- Dashboard with energy-use summary and charts.
- Search/filter building records and add/delete records in the current browser session.
- Ten SQL report examples with illustrative results.
- Ten additional chart/visualization styles.
- Import CSV records and export the current records to CSV.
- Responsive layout for laptop and mobile screens.

## Energy calculation
Energy Use Intensity (EUI) = Annual electricity consumption (kWh) / Floor area (m²).

The demonstration uses illustrative sample data. Records added or imported in the website are held in browser memory for that session; this is not connected to a live database and changes are not permanently saved. The SQL files are provided as database implementation/reference material.

## Project details shown in the website
- Sandhiya Chandran – 1925260341
- Rishika B – 1924260081
- S Monisha Reddy – 192524152
- Guide: Dr S Sankar
- Course: CSA0503 – Database Management Systems
