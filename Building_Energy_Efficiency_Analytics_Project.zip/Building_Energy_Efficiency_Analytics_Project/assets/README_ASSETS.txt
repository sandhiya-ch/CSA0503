project-flow.svg is a simple overview of the data-to-insights workflow. The dashboard charts are drawn directly by JavaScript Canvas, so no external image or chart library is required.
