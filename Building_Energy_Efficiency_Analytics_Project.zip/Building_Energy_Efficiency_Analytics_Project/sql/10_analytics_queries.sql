-- Building Energy Efficiency Analytics: SQLite-compatible reference SQL
CREATE TABLE IF NOT EXISTS building_energy (
  building_id INTEGER PRIMARY KEY AUTOINCREMENT,
  building_name TEXT NOT NULL,
  building_type TEXT NOT NULL,
  floor_area_m2 REAL NOT NULL CHECK (floor_area_m2 > 0),
  annual_kwh REAL NOT NULL CHECK (annual_kwh >= 0),
  outdoor_temp_c REAL,
  efficiency_rating TEXT
);

-- Load the sample CSV using your SQLite client’s CSV import feature.

-- 1. Total annual energy consumption
SELECT SUM(annual_kwh) AS total_energy_kwh FROM building_energy;

-- 2. Average energy use intensity (EUI)
SELECT AVG(annual_kwh / floor_area_m2) AS avg_eui FROM building_energy;

-- 3. Efficiency rating distribution
SELECT efficiency_rating, COUNT(*) AS building_count
FROM building_energy GROUP BY efficiency_rating ORDER BY efficiency_rating;

-- 4. Top 5 energy-consuming buildings
SELECT building_name, annual_kwh FROM building_energy
ORDER BY annual_kwh DESC LIMIT 5;

-- 5. Energy consumption by building type
SELECT building_type, SUM(annual_kwh) AS total_kwh
FROM building_energy GROUP BY building_type ORDER BY total_kwh DESC;

-- 6. Average EUI by building type
SELECT building_type, AVG(annual_kwh / floor_area_m2) AS avg_eui
FROM building_energy GROUP BY building_type;

-- 7. Buildings above the EUI benchmark of 30
SELECT building_name, annual_kwh / floor_area_m2 AS eui
FROM building_energy WHERE annual_kwh / floor_area_m2 >= 30
ORDER BY eui DESC;

-- 8. Average outdoor temperature by building type
SELECT building_type, AVG(outdoor_temp_c) AS avg_temp_c
FROM building_energy GROUP BY building_type;

-- 9. Floor area and energy per square metre
SELECT building_name, floor_area_m2, annual_kwh,
       ROUND(annual_kwh / floor_area_m2, 2) AS eui
FROM building_energy ORDER BY eui DESC;

-- 10. Potential energy saving at 10 percent
SELECT building_name, annual_kwh,
       annual_kwh * 0.10 AS estimated_saving_kwh
FROM building_energy ORDER BY estimated_saving_kwh DESC;
