CREATE TABLE building_energy (
  building_id INTEGER PRIMARY KEY AUTOINCREMENT,
  building_name TEXT NOT NULL,
  building_type TEXT NOT NULL,
  floor_area_m2 REAL NOT NULL CHECK (floor_area_m2 > 0),
  annual_kwh REAL NOT NULL CHECK (annual_kwh >= 0),
  outdoor_temp_c REAL,
  efficiency_rating TEXT
);
